ATTACH TABLE warehouse_delivery_kafka
(
    id String, 
    no String, 
    code String, 
    parentCode String, 
    childCode String, 
    createTime DateTime
)
ENGINE = Kafka('47.105.34.243:9092', 'Trace_WarehouseDelivery', 'WarehouseDelivery', 'JSONEachRow')
