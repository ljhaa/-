ATTACH MATERIALIZED VIEW in_storage
(
    day Date, 
    id String, 
    no String, 
    code String, 
    parent_code String, 
    child_code String, 
    create_time DateTime
)
ENGINE = MergeTree(day, (day, id, no, code, parent_code, child_code, create_time), 8192) AS
SELECT 
    toDate(create_time) AS day, 
    id, 
    no, 
    code, 
    parentCode AS parent_code, 
    childCode AS child_code, 
    createTime AS create_time
FROM ck.in_storage_kafka 
