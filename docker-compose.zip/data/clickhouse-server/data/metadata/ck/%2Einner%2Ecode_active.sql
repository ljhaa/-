ATTACH TABLE `.inner.code_active`
(
    day Date, 
    id String, 
    provider_code String, 
    provider_name String, 
    product_code String, 
    product_name String, 
    feature_code Int8, 
    trace_code String, 
    parent_code String, 
    create_user String, 
    create_time DateTime, 
    batch String, 
    dept_name String, 
    line_name String, 
    product_time DateTime
)
ENGINE = MergeTree(day, (day, id, provider_code, provider_name, product_code, product_name, feature_code, trace_code, parent_code, create_user, create_time, batch, dept_name, line_name, product_time), 8192)
