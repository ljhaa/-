ATTACH TABLE code_active_kafka
(
    id String, 
    providerCode String, 
    providerName String, 
    productCode String, 
    productName String, 
    featureCode Int8, 
    traceCode String, 
    parentCode String, 
    createUser String, 
    createTime DateTime, 
    batch String, 
    deptName String, 
    lineName String, 
    productTime DateTime
)
ENGINE = Kafka('47.105.34.243:9092', 'Trace_CodeActive', 'CodeActive', 'JSONEachRow')
