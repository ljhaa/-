ATTACH MATERIALIZED VIEW code_active
(
    day Date, 
    id String, 
    provider_code String, 
    provider_name String, 
    product_code String, 
    product_name String, 
    feature_code Int8, 
    trace_code String, 
    parent_code String, 
    create_user String, 
    create_time DateTime, 
    batch String, 
    dept_name String, 
    line_name String, 
    product_time DateTime
)
ENGINE = MergeTree(day, (day, id, provider_code, provider_name, product_code, product_name, feature_code, trace_code, parent_code, create_user, create_time, batch, dept_name, line_name, product_time), 8192) AS
SELECT 
    toDate(create_time) AS day, 
    id, 
    providerCode AS provider_code, 
    providerName AS provider_name, 
    productCode AS product_code, 
    productName AS product_name, 
    featureCode AS feature_code, 
    traceCode AS trace_code, 
    parentCode AS parent_code, 
    createUser AS create_user, 
    createTime AS create_time, 
    batch, 
    deptName AS dept_name, 
    lineName AS line_name, 
    productTime AS product_time
FROM ck.code_active_kafka 
