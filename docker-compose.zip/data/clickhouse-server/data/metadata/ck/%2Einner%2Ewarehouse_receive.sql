ATTACH TABLE `.inner.warehouse_receive`
(
    day Date, 
    id String, 
    no String, 
    code String, 
    parent_code String, 
    child_code String, 
    create_time DateTime
)
ENGINE = MergeTree(day, (day, id, no, code, parent_code, child_code, create_time), 8192)
